# Android-Bubble-Chat
Simple bubble chat message example code.
<br/>
![alt tag](http://i.imgur.com/Vp98Jam.gif)
